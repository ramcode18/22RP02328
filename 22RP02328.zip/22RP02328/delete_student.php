<?php
include('conn.php');
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $delete = "DELETE FROM students WHERE id=$id";
    if (mysqli_query($conn, $delete)) {
        header("Location: dashboard.php");
    } else {
        echo "Error: " . $delete . "<br>" . mysqli_error($conn);
    }
} else {
    header("Location: dashboard.php");
}
?>
