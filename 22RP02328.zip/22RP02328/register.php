<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register</title>
    <style type="text/css">
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }
        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: calc(100% - 24px);
            border: 1px solid #ccc;
            border-radius: 20px;
            padding: 10px;
            margin-bottom: 10px;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 20px;
            padding: 10px 20px;
            cursor: pointer;
            width: 100%;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <form action="login.php" method="post">
        Username:<br> <input type="text" name="username" required><br>
        Password: <br><input type="password" name="password" required><br>
        Email:<br> <input type="email" name="email" required><br>
        <input type="submit" name="register" value="Register">
    </form>

    <?php
    include('conn.php');
    if (isset($_POST['register'])) {
        $username = mysqli_real_escape_string($conn, $_POST['username']);
        $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
        $email = mysqli_real_escape_string($conn, $_POST['email']);

        $query = "SELECT * FROM users WHERE username='$username' OR email='$email'";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            echo "Username or email already taken.";
        } else {
            $insert = "INSERT INTO users (username, password, email) VALUES ('$username', '$password', '$email')";
            if (mysqli_query($conn, $insert)) {
                echo "User registered successfully.";
            } else {
                echo "Error: " . $insert . "<br>" . mysqli_error($conn);
            }
        }
    }
    ?>
</body>
</html>
