<?php
$serva = "localhost";
$user = "root";
$password = "";
$db = "student_management";

$conn = mysqli_connect($serva, $user, $password, $db);
if (!$conn) {
    die("Failed to connect to database: " . mysqli_connect_error());
}
?>
