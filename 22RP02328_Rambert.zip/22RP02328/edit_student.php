<?php
session_start();
include('conn.php');
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$id = $_GET['id'];
$query = "SELECT * FROM students WHERE id='$id'";
$result = mysqli_query($conn, $query);
$student = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Student</title>
</head>
<body>
    <form action="update_student.php" method="post">
        <input type="hidden" name="id" value="<?php echo $student['id']; ?>">
        First Name: <input type="text" name="fname" value="<?php echo $student['fname']; ?>" required><br>
        Last Name: <input type="text" name="lname" value="<?php echo $student['lname']; ?>" required><br>
        Email: <input type="email" name="email" value="<?php echo $student['email']; ?>" required><br>
        Phone: <input type="text" name="phone" value="<?php echo $student['phone']; ?>"><br>
        Address: <input type="text" name="address" value="<?php echo $student['address']; ?>"><br>
        Year of Study: <input type="number" name="year_of_study" value="<?php echo $student['year_of_study']; ?>" required><br>
        <input type="submit" name="update_student" value="Update Student">
    </form>
</body>
</html>
