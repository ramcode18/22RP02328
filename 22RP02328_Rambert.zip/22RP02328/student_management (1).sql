-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 06, 2024 at 09:52 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `year_of_study` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `fname`, `lname`, `email`, `phone`, `address`, `year_of_study`, `created_at`) VALUES
(2, 'clemaance', 'JEAN', 'likeonee18@gmail.com', '0789033577', 'nyagatare', 3456, '2024-08-06 15:00:11'),
(3, 'HAKORIMANA', 'Rambert', 'likeonee18@gmail.com', '0789033570', 'nyagatare', 234, '2024-08-06 15:05:01'),
(5, 'HAKORIMANA', 'Rambert', 'og@gmail.com', '0789033570', 'kayonza', 2020, '2024-08-06 19:06:55'),
(6, 'Bimenyimana', 'Valens', 'valens@gmail.com', '0789033570', 'Kayonza', 2020, '2024-08-06 19:12:58'),
(7, 'Phoibe', 'Musabeyezu ', 'rambertshimwe18@gmail.com', '0789033570', 'nyagatare', 2012, '2024-08-06 19:27:05');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `role` varchar(50) DEFAULT 'admin'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `created_at`, `role`) VALUES
(1, 'admin', '$2y$10$VjFQxDz4cp.QlFyI8C0vJOjaaTaXf2A9QyFAbJ5h3tSsvX0kucJkS', 'rambertshimwe18@gmail.com', '2024-08-06 14:57:29', 'admin'),
(2, 'rambert', '$2y$10$ch5agTyOnQOx38/UDgpIWun4ouBlO5HAAFMvXesvyICNwrEFqNcSq', 'og@gmail.com', '2024-08-06 15:02:29', 'admin'),
(3, 'clemance', '$2y$10$f/RGTemKjKSET8W5JXV3ZuPHOplw5..2meMuMEMj0q4YekxYIv50m', 'clemance@gmail.com', '2024-08-06 19:17:53', 'admin'),
(4, 'mani', '$2y$10$NfsvugpWqr7sxvvmQQfureupAdNzZRZXd6.0ZbL31rLG1qyRg.5NG', 'mani@gmail.com', '2024-08-06 19:45:25', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
