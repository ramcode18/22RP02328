<?php
session_start();
include('conn.php');
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (isset($_POST['update_student'])) {
    $id = $_POST['id'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $year_of_study = $_POST['year_of_study'];

    $update = "UPDATE students SET fname='$fname', lname='$lname', email='$email', phone='$phone', address='$address', year_of_study='$year_of_study' WHERE id='$id'";
    if (mysqli_query($conn, $update)) {
        header("Location: dashboard.php");
    } else {
        echo "Error: " . $update . "<br>" . mysqli_error($conn);
    }
}
?>
